-- Adminer 4.6.3 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `access_token` text NOT NULL,
  `email` varchar(255) NOT NULL,
  `created_date` date NOT NULL,
  `updated_date` date NOT NULL,
  `status` int(11) NOT NULL,
  `last_login` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `admin` (`id`, `user_name`, `password`, `access_token`, `email`, `created_date`, `updated_date`, `status`, `last_login`) VALUES
(1,	'admin',	'admin',	'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwiaWF0IjoxNTY0NzQwNTMxLCJleHAiOjE1NjQ4MjY5MzF9.9XNRm94tKjHm1OwzhozBJxLak7QtLweDXglO5ly55js',	'admin@admin.com',	'2019-05-15',	'2019-05-15',	1,	'2019-05-15 12:06:20');

DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) NOT NULL,
  `category_description` text NOT NULL,
  `category_image` text NOT NULL,
  `sort_order` int(11) NOT NULL,
  `created_date` date NOT NULL,
  `updated_date` date NOT NULL,
  `parent_category` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `categories` (`id`, `category_name`, `category_description`, `category_image`, `sort_order`, `created_date`, `updated_date`, `parent_category`, `status`) VALUES
(26,	'Cat 1',	'Cate',	'user/eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IkNhdCAxIiwiaWF0IjoxNTU4NjAzOTE0fQ.F6yzbMCyPIzuxiP7Fn84GDlWMt8y4biGBZKsHZ3I6cc.jpg',	0,	'2019-05-23',	'2019-05-23',	0,	1),
(27,	'Cat 2',	'Cat',	'user/eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IkNhdCAyIiwiaWF0IjoxNTU4NjAzOTIwfQ.MPLoK-ZGy0SU50uidqRpLdLZrPEVWm45joR_46109pQ.jpg',	0,	'2019-05-23',	'2019-05-23',	0,	1),
(28,	'Cat 3',	'Cat',	'user/eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IkNhdCAzIiwiaWF0IjoxNTU4NjAzOTI1fQ.1oVYiqtbCmPAyWu3rlftGERy-hMYHpIStKvsnkebG44.jpg',	0,	'2019-05-23',	'2019-05-23',	0,	1),
(29,	'Mobile',	'Mobile',	'user/eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IkNhdCA0IiwiaWF0IjoxNTU4NjAzOTMyfQ.6AUFBlcJGTTxE5c5Ua9Ep6rdsph5eKU89MixxapiZn8.jpg',	0,	'2019-05-23',	'2019-05-23',	0,	1),
(30,	'Cat 5',	'Cat',	'user/eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IkNhdCA1IiwiaWF0IjoxNTU4NjAzOTM3fQ.u1uLvZNwwNZYqh2wISMVb0K-OAmGoA5pyZKPe_407Sw.jpg',	0,	'2019-05-23',	'2019-05-23',	0,	1),
(31,	'Cat 6',	'Cat',	'user/eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IkNhdCA2IiwiaWF0IjoxNTU4NjAzOTQyfQ.Psso34I2Wn6dU3W4_mi4ARbO0LhlfpqqctG9u3jPj78.jpg',	0,	'2019-05-23',	'2019-05-23',	0,	1),
(32,	'Home Appliances',	'Cat',	'user/eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IkNhdCA3IiwiaWF0IjoxNTU4NjAzOTQ3fQ.MbOj9icD65lAC5gFDEt1tPi4js4loUV7RExCkNYNumw.jpg',	0,	'2019-05-23',	'2019-05-23',	0,	1),
(33,	'Tv',	'Cat',	'user/eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MzMsImlhdCI6MTU2MjMyMTczOH0.CUIUoIrRNSUQemc20pP6P6AZRGWnV58-vfyl9A2Rnk0.png',	0,	'2019-05-23',	'2019-05-23',	0,	1);

DROP TABLE IF EXISTS `customer`;
CREATE TABLE `customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cust_first_name` varchar(255) NOT NULL,
  `cust_last_name` varchar(255) NOT NULL,
  `cust_email` varchar(255) NOT NULL,
  `cust_password` text NOT NULL,
  `cust_access_token` text NOT NULL,
  `cust_image` text NOT NULL,
  `created_date` date NOT NULL,
  `updated_date` date NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `customer` (`id`, `cust_first_name`, `cust_last_name`, `cust_email`, `cust_password`, `cust_access_token`, `cust_image`, `created_date`, `updated_date`, `status`) VALUES
(1,	'Vijaiii',	'Jeraldd',	'vijai@gmail.com',	'12345',	'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwiaWF0IjoxNTYxNzE4MzQxLCJleHAiOjE1NjE4MDQ3NDF9.iKNi9LhuixeaEiEBHIzu0nJ9JXMWQdr2YhoIx5QutEY',	'profile/eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjEiLCJpYXQiOjE1NjE0NzIwNjB9.rjDpa7-S1NSIk3yjRna1CYnRNr4sIYKSQuyPsDp4fqQ.jpg',	'2019-06-10',	'2019-06-10',	1),
(2,	'Vijai',	'Jerald',	'vijaid@gmail.com',	'234234',	'sdfsdfsdfsdf',	'dfsdfsdf',	'2018-01-19',	'2018-01-19',	1),
(3,	'Vijai',	'Jerald',	'vijaih@gmail.com',	'dfgdfgd',	'dfgdfgd',	'dfgdfg',	'2019-01-19',	'2020-01-19',	0),
(4,	'Vijai',	'Jerald',	'vijaihe@gmail.com',	'gdfgdf',	'gdfgdfg',	'dfgdfgdf',	'2020-01-19',	'2020-01-19',	0);

DROP TABLE IF EXISTS `customer_address`;
CREATE TABLE `customer_address` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `city` text NOT NULL,
  `state` text NOT NULL,
  `pincode` int(11) NOT NULL,
  `country` text NOT NULL,
  `mobile_no` text NOT NULL,
  `address_type` text NOT NULL,
  `created_date` date NOT NULL,
  `updated_date` date NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `customer_id` (`customer_id`),
  CONSTRAINT `customer_address_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `customer_address` (`id`, `customer_id`, `name`, `address`, `city`, `state`, `pincode`, `country`, `mobile_no`, `address_type`, `created_date`, `updated_date`, `status`) VALUES
(1,	1,	'dsgsdg',	'sdgsdg',	'ssgdsdg',	'sdgsdg',	35235,	'',	'43523525',	'customer',	'2019-06-12',	'2019-06-12',	1),
(2,	1,	'second',	'second',	'second',	'second',	35235,	'',	'235235235',	'customer',	'2019-06-12',	'2019-06-12',	1),
(3,	1,	'third',	'third',	'third',	'third',	35235,	'',	'352352',	'customer',	'2019-06-12',	'2019-06-12',	1),
(4,	1,	'hskf',	'sdkgsgd',	'sdgsg',	'sdgg',	77474,	'',	'345345',	'shipping',	'2019-06-12',	'2019-06-12',	1),
(5,	1,	'Fifth',	'Fifth',	'Fifth',	'Fifth',	552,	'',	'3523523',	'shipping',	'2019-06-13',	'2019-06-13',	1),
(6,	1,	'Fifth',	'Fifth',	'Fifth',	'Fifth',	552,	'Fifth',	'3523523',	'shipping',	'2019-06-13',	'2019-06-13',	1),
(7,	1,	'dfd',	'dfh',	'dfh',	'dfh',	43534,	'fh',	'46346',	'customer',	'2019-06-28',	'2019-06-28',	1);

DROP TABLE IF EXISTS `customer_temp_cart`;
CREATE TABLE `customer_temp_cart` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `cart_datas` text NOT NULL,
  `created_date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `customer_temp_cart` (`id`, `user_id`, `cart_datas`, `created_date`) VALUES
(1,	1,	'[{\"image\":[{\"image\":\"product/eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6Ik1PYmkxIiwiaWF0IjoxNTU5MjEyODIwfQ.957Lxsr_-S2BH5DDirYrTBnVyQFsuRI0qGm3MhHsGps0.jpg\",\"status\":1,\"product_id\":28},{\"image\":\"product/eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6Ik1PYmkxIiwiaWF0IjoxNTU5MjEyODIwfQ.957Lxsr_-S2BH5DDirYrTBnVyQFsuRI0qGm3MhHsGps1.jpg\",\"status\":1,\"product_id\":28}],\"product\":{\"id\":27,\"product_name\":\"Mi MObile\",\"product_description\":\"Mobile\",\"product_price\":10000,\"product_offer_price\":0,\"product_unique_id\":\"MObi1\",\"product_quantity\":100,\"product_status\":\"IN STOCK\",\"product_brand_name\":\"\",\"created_date\":\"2019-05-29T18:30:00.000Z\",\"updated_date\":\"2019-05-29T18:30:00.000Z\",\"status\":1,\"product_id\":28,\"category_id\":29,\"pproduct_id\":28,\"isAddedToCart\":true,\"pquantity\":1}},{\"image\":[{\"image\":\"product/eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IlJFRjAxIiwiaWF0IjoxNTU5MTIxNjEwfQ.S3OwPJi2qEBqYPFY56vMUKhY-wDIqV4lPkaRZiwR0ho0.jpg\",\"status\":1,\"product_id\":27}],\"product\":{\"id\":26,\"product_name\":\"Refrigerator\",\"product_description\":\"Cooling machine\",\"product_price\":15000,\"product_offer_price\":0,\"product_unique_id\":\"REF01\",\"product_quantity\":100,\"product_status\":\"IN STOCK\",\"product_brand_name\":\"\",\"created_date\":\"2019-05-28T18:30:00.000Z\",\"updated_date\":\"2019-05-28T18:30:00.000Z\",\"status\":1,\"product_id\":27,\"category_id\":32,\"pproduct_id\":27,\"isAddedToCart\":0,\"pquantity\":0}},{\"image\":[{\"image\":\"product/eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IlRWMSIsImlhdCI6MTU1OTExMTA5Mn0.ABsqcz1Di9cMOlUzlbh9bRnCgYq4CyCZnLQc9sgeCHc0.jpg\",\"status\":1,\"product_id\":26},{\"image\":\"product/eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IlRWMSIsImlhdCI6MTU1OTExMTA5Mn0.ABsqcz1Di9cMOlUzlbh9bRnCgYq4CyCZnLQc9sgeCHc1.jpg\",\"status\":1,\"product_id\":26}],\"product\":{\"id\":25,\"product_name\":\"LCD Television\",\"product_description\":\"Smart TV\",\"product_price\":12000,\"product_offer_price\":0,\"product_unique_id\":\"TV1\",\"product_quantity\":200,\"product_status\":\"IN STOCK\",\"product_brand_name\":\"\",\"created_date\":\"2019-05-28T18:30:00.000Z\",\"updated_date\":\"2019-05-28T18:30:00.000Z\",\"status\":1,\"product_id\":26,\"category_id\":33,\"pproduct_id\":26,\"isAddedToCart\":0,\"pquantity\":0}}]',	'0000-00-00');

DROP TABLE IF EXISTS `order`;
CREATE TABLE `order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `address_id` int(11) NOT NULL,
  `shipping_address_id` int(11) NOT NULL,
  `order_status` int(11) NOT NULL,
  `delivered_date` date NOT NULL,
  `created_date` date NOT NULL,
  `updated_date` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `customer_id` (`customer_id`),
  CONSTRAINT `order_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`) ON DELETE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `order` (`id`, `customer_id`, `address_id`, `shipping_address_id`, `order_status`, `delivered_date`, `created_date`, `updated_date`) VALUES
(9,	1,	1,	6,	0,	'2019-06-14',	'2019-06-14',	'2019-06-14'),
(10,	1,	3,	6,	2,	'2019-06-19',	'2018-06-19',	'2019-06-19'),
(11,	1,	1,	4,	3,	'2019-06-28',	'2019-06-28',	'2019-06-28');

DROP TABLE IF EXISTS `order_product`;
CREATE TABLE `order_product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_name` text NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `offer_price` int(11) NOT NULL,
  `created_date` date NOT NULL,
  `updated_date` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  CONSTRAINT `order_product_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `order` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `order_product` (`id`, `order_id`, `product_id`, `product_name`, `quantity`, `price`, `offer_price`, `created_date`, `updated_date`) VALUES
(1,	9,	28,	'Mi MObile',	1,	10000,	0,	'2019-06-14',	'2019-06-14'),
(2,	9,	27,	'Refrigerator',	1,	15000,	0,	'2019-06-14',	'2019-06-14'),
(3,	10,	28,	'Mi MObile',	1,	10000,	0,	'2019-06-19',	'2019-06-19'),
(4,	11,	28,	'Mi MObile',	1,	10000,	0,	'2018-06-28',	'2019-06-28'),
(5,	11,	27,	'Refrigerator',	1,	15000,	0,	'2019-06-28',	'2019-06-28'),
(6,	11,	26,	'LCD Television',	1,	12000,	0,	'2019-06-28',	'2019-06-28');

DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_name` varchar(255) NOT NULL,
  `product_description` text NOT NULL,
  `product_price` int(11) NOT NULL,
  `product_offer_price` int(11) NOT NULL,
  `product_unique_id` varchar(255) NOT NULL,
  `product_quantity` int(11) NOT NULL,
  `product_status` varchar(255) NOT NULL,
  `product_brand_name` varchar(255) NOT NULL,
  `created_date` date NOT NULL,
  `updated_date` date NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `products` (`id`, `product_name`, `product_description`, `product_price`, `product_offer_price`, `product_unique_id`, `product_quantity`, `product_status`, `product_brand_name`, `created_date`, `updated_date`, `status`) VALUES
(26,	'LCD Television',	'Smart TV',	12000,	0,	'TV1',	200,	'IN STOCK',	'',	'2019-05-29',	'2019-05-29',	1),
(27,	'Refrigerator',	'Cooling machine',	15000,	0,	'REF01',	100,	'IN STOCK',	'',	'2019-05-29',	'2019-05-29',	1),
(28,	'Mi MObile',	'Mobile',	10000,	0,	'MObi1',	100,	'IN STOCK',	'',	'2019-05-30',	'2019-05-30',	1);

DROP TABLE IF EXISTS `product_category`;
CREATE TABLE `product_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `product_category` (`id`, `product_id`, `category_id`) VALUES
(1,	1,	26),
(2,	2,	30),
(3,	3,	31),
(4,	4,	31),
(5,	5,	29),
(6,	6,	30),
(7,	7,	33),
(8,	8,	32),
(9,	9,	31),
(10,	10,	30),
(11,	11,	29),
(12,	12,	30),
(13,	13,	29),
(14,	14,	30),
(15,	15,	31),
(16,	16,	31),
(17,	18,	31),
(18,	19,	30),
(19,	20,	31),
(20,	21,	32),
(21,	22,	32),
(22,	23,	31),
(23,	24,	33),
(24,	25,	31),
(25,	26,	33),
(26,	27,	32),
(27,	28,	29);

DROP TABLE IF EXISTS `product_images`;
CREATE TABLE `product_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `image` text NOT NULL,
  `created_date` date NOT NULL,
  `updated_date` date NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `product_images_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `product_images` (`id`, `product_id`, `image`, `created_date`, `updated_date`, `status`) VALUES
(4,	26,	'product/eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IlRWMSIsImlhdCI6MTU1OTExMTA5Mn0.ABsqcz1Di9cMOlUzlbh9bRnCgYq4CyCZnLQc9sgeCHc0.jpg',	'2019-05-29',	'2019-05-29',	1),
(5,	26,	'product/eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IlRWMSIsImlhdCI6MTU1OTExMTA5Mn0.ABsqcz1Di9cMOlUzlbh9bRnCgYq4CyCZnLQc9sgeCHc1.jpg',	'2019-05-29',	'2019-05-29',	1),
(6,	27,	'product/eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IlJFRjAxIiwiaWF0IjoxNTU5MTIxNjEwfQ.S3OwPJi2qEBqYPFY56vMUKhY-wDIqV4lPkaRZiwR0ho0.jpg',	'2019-05-29',	'2019-05-29',	1),
(7,	27,	'product/eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IlJFRjAxIiwiaWF0IjoxNTU5MTIxNjEwfQ.S3OwPJi2qEBqYPFY56vMUKhY-wDIqV4lPkaRZiwR0ho0.jpg',	'2018-01-19',	'2018-01-19',	0),
(8,	28,	'product/eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6Ik1PYmkxIiwiaWF0IjoxNTU5MjEyODIwfQ.957Lxsr_-S2BH5DDirYrTBnVyQFsuRI0qGm3MhHsGps0.jpg',	'2019-05-30',	'2019-05-30',	1),
(9,	28,	'product/eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6Ik1PYmkxIiwiaWF0IjoxNTU5MjEyODIwfQ.957Lxsr_-S2BH5DDirYrTBnVyQFsuRI0qGm3MhHsGps1.jpg',	'2019-05-30',	'2019-05-30',	1);

-- 2019-08-02 10:28:35
